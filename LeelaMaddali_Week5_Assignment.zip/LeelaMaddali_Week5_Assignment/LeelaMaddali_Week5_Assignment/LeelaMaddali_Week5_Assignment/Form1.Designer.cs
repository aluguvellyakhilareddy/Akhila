﻿namespace LeelaMaddali_Week5_Assignment
{
    partial class HotelBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Namelabel = new System.Windows.Forms.Label();
            this.firstnametextBox = new System.Windows.Forms.TextBox();
            this.lastnametextBox = new System.Windows.Forms.TextBox();
            this.emaillabel = new System.Windows.Forms.Label();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.Roomtypelabel = new System.Windows.Forms.Label();
            this.No_of_Guests_label = new System.Windows.Forms.Label();
            this.Arrival_label = new System.Windows.Forms.Label();
            this.Departure_label = new System.Windows.Forms.Label();
            this.DeparturedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ArrivaldateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.NoofGuestsnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Borderlabel = new System.Windows.Forms.Label();
            this.HotelName_label = new System.Windows.Forms.Label();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.Summary_label = new System.Windows.Forms.Label();
            this.Caption_label = new System.Windows.Forms.Label();
            this.Titlelabel = new System.Windows.Forms.Label();
            this.TitlecomboBox = new System.Windows.Forms.ComboBox();
            this.Street_Address_label = new System.Windows.Forms.Label();
            this.Province_label = new System.Windows.Forms.Label();
            this.Citylabel = new System.Windows.Forms.Label();
            this.PostalCode_label = new System.Windows.Forms.Label();
            this.Country_label = new System.Windows.Forms.Label();
            this.Phone_No_label = new System.Windows.Forms.Label();
            this.Street_Address_textBox = new System.Windows.Forms.TextBox();
            this.CitytextBox = new System.Windows.Forms.TextBox();
            this.ProvincetextBox = new System.Windows.Forms.TextBox();
            this.CountrytextBox = new System.Windows.Forms.TextBox();
            this.PostalCodetextBox = new System.Windows.Forms.TextBox();
            this.Phone_No_textBox = new System.Windows.Forms.TextBox();
            this.No_of_Nights_label = new System.Windows.Forms.Label();
            this.NoOfNights_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Room_TypetextBox = new System.Windows.Forms.TextBox();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Time_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.NoofGuestsnumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfNights_numericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Namelabel.Location = new System.Drawing.Point(14, 155);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(51, 16);
            this.Namelabel.TabIndex = 0;
            this.Namelabel.Text = "Name:";
            // 
            // firstnametextBox
            // 
            this.firstnametextBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.firstnametextBox.Location = new System.Drawing.Point(180, 150);
            this.firstnametextBox.Name = "firstnametextBox";
            this.firstnametextBox.Size = new System.Drawing.Size(166, 22);
            this.firstnametextBox.TabIndex = 1;
            this.firstnametextBox.Text = "First Name";
            this.firstnametextBox.Click += new System.EventHandler(this.firstnametextBox_Click);
            this.firstnametextBox.Enter += new System.EventHandler(this.firstnametextBox_Enter);
            this.firstnametextBox.Leave += new System.EventHandler(this.firstnametextBox_Leave);
            // 
            // lastnametextBox
            // 
            this.lastnametextBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.lastnametextBox.Location = new System.Drawing.Point(367, 150);
            this.lastnametextBox.Name = "lastnametextBox";
            this.lastnametextBox.Size = new System.Drawing.Size(166, 22);
            this.lastnametextBox.TabIndex = 2;
            this.lastnametextBox.Text = "Last Name";
            this.lastnametextBox.Click += new System.EventHandler(this.lastnametextBox_Click);
            this.lastnametextBox.Enter += new System.EventHandler(this.lastnametextBox_Enter);
            this.lastnametextBox.Leave += new System.EventHandler(this.lastnametextBox_Leave);
            // 
            // emaillabel
            // 
            this.emaillabel.AutoSize = true;
            this.emaillabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emaillabel.ForeColor = System.Drawing.SystemColors.Desktop;
            this.emaillabel.Location = new System.Drawing.Point(20, 379);
            this.emaillabel.Name = "emaillabel";
            this.emaillabel.Size = new System.Drawing.Size(54, 16);
            this.emaillabel.TabIndex = 5;
            this.emaillabel.Text = "E-Mail:";
            // 
            // emailtextBox
            // 
            this.emailtextBox.AccessibleDescription = "";
            this.emailtextBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.emailtextBox.Location = new System.Drawing.Point(180, 379);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(278, 22);
            this.emailtextBox.TabIndex = 6;
            this.emailtextBox.Text = "eg: abc@xyz.com";
            this.emailtextBox.Click += new System.EventHandler(this.emailtextBox_Click);
            this.emailtextBox.Enter += new System.EventHandler(this.emailtextBox_Enter_1);
            this.emailtextBox.Leave += new System.EventHandler(this.emailtextBox_Leave);
            // 
            // Roomtypelabel
            // 
            this.Roomtypelabel.AutoSize = true;
            this.Roomtypelabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roomtypelabel.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Roomtypelabel.Location = new System.Drawing.Point(20, 479);
            this.Roomtypelabel.Name = "Roomtypelabel";
            this.Roomtypelabel.Size = new System.Drawing.Size(88, 16);
            this.Roomtypelabel.TabIndex = 7;
            this.Roomtypelabel.Text = "Room Type:";
            // 
            // No_of_Guests_label
            // 
            this.No_of_Guests_label.AutoSize = true;
            this.No_of_Guests_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.No_of_Guests_label.ForeColor = System.Drawing.SystemColors.Desktop;
            this.No_of_Guests_label.Location = new System.Drawing.Point(20, 431);
            this.No_of_Guests_label.Name = "No_of_Guests_label";
            this.No_of_Guests_label.Size = new System.Drawing.Size(135, 16);
            this.No_of_Guests_label.TabIndex = 9;
            this.No_of_Guests_label.Text = "Number of Guests:";
            // 
            // Arrival_label
            // 
            this.Arrival_label.AutoSize = true;
            this.Arrival_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arrival_label.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Arrival_label.Location = new System.Drawing.Point(20, 519);
            this.Arrival_label.Name = "Arrival_label";
            this.Arrival_label.Size = new System.Drawing.Size(145, 16);
            this.Arrival_label.TabIndex = 11;
            this.Arrival_label.Text = "Arrival Date && Time:";
            // 
            // Departure_label
            // 
            this.Departure_label.AutoSize = true;
            this.Departure_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Departure_label.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Departure_label.Location = new System.Drawing.Point(20, 574);
            this.Departure_label.Name = "Departure_label";
            this.Departure_label.Size = new System.Drawing.Size(115, 16);
            this.Departure_label.TabIndex = 23;
            this.Departure_label.Text = "Departure Date:";
            // 
            // DeparturedateTimePicker
            // 
            this.DeparturedateTimePicker.CustomFormat = "MM-dd-yyyy";
            this.DeparturedateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DeparturedateTimePicker.Location = new System.Drawing.Point(180, 568);
            this.DeparturedateTimePicker.Name = "DeparturedateTimePicker";
            this.DeparturedateTimePicker.Size = new System.Drawing.Size(119, 22);
            this.DeparturedateTimePicker.TabIndex = 31;
            this.DeparturedateTimePicker.Value = new System.DateTime(2020, 3, 4, 18, 46, 37, 0);
            this.DeparturedateTimePicker.Enter += new System.EventHandler(this.DeparturedateTimePicker_Enter);
            // 
            // ArrivaldateTimePicker
            // 
            this.ArrivaldateTimePicker.CustomFormat = "MM-dd-yyy";
            this.ArrivaldateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ArrivaldateTimePicker.Location = new System.Drawing.Point(180, 519);
            this.ArrivaldateTimePicker.Name = "ArrivaldateTimePicker";
            this.ArrivaldateTimePicker.Size = new System.Drawing.Size(122, 22);
            this.ArrivaldateTimePicker.TabIndex = 30;
            this.ArrivaldateTimePicker.Value = new System.DateTime(2020, 3, 4, 0, 0, 0, 0);
            this.ArrivaldateTimePicker.Enter += new System.EventHandler(this.ArrivaldateTimePicker_Enter);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(181, 544);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 15;
            // 
            // NoofGuestsnumericUpDown
            // 
            this.NoofGuestsnumericUpDown.Location = new System.Drawing.Point(180, 431);
            this.NoofGuestsnumericUpDown.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.NoofGuestsnumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NoofGuestsnumericUpDown.Name = "NoofGuestsnumericUpDown";
            this.NoofGuestsnumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.NoofGuestsnumericUpDown.TabIndex = 33;
            this.NoofGuestsnumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NoofGuestsnumericUpDown.Click += new System.EventHandler(this.NoofGuestsnumericUpDown_Click);
            this.NoofGuestsnumericUpDown.Leave += new System.EventHandler(this.NoofGuestsnumericUpDown_Leave);
            // 
            // Borderlabel
            // 
            this.Borderlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Borderlabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Borderlabel.Location = new System.Drawing.Point(-2, 80);
            this.Borderlabel.Name = "Borderlabel";
            this.Borderlabel.Size = new System.Drawing.Size(791, 3);
            this.Borderlabel.TabIndex = 35;
            this.Borderlabel.UseWaitCursor = true;
            // 
            // HotelName_label
            // 
            this.HotelName_label.AutoSize = true;
            this.HotelName_label.Font = new System.Drawing.Font("Brush Script Std", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HotelName_label.ForeColor = System.Drawing.Color.Black;
            this.HotelName_label.Location = new System.Drawing.Point(340, 9);
            this.HotelName_label.Name = "HotelName_label";
            this.HotelName_label.Size = new System.Drawing.Size(109, 28);
            this.HotelName_label.TabIndex = 36;
            this.HotelName_label.Text = "Rosewood";
            // 
            // Submitbutton
            // 
            this.Submitbutton.AllowDrop = true;
            this.Submitbutton.Location = new System.Drawing.Point(20, 689);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(86, 33);
            this.Submitbutton.TabIndex = 37;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = true;
            this.Submitbutton.Click += new System.EventHandler(this.Submitbutton_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Summary_label
            // 
            this.Summary_label.AutoSize = true;
            this.Summary_label.Location = new System.Drawing.Point(253, 689);
            this.Summary_label.Name = "Summary_label";
            this.Summary_label.Size = new System.Drawing.Size(0, 17);
            this.Summary_label.TabIndex = 38;
            // 
            // Caption_label
            // 
            this.Caption_label.AutoSize = true;
            this.Caption_label.Font = new System.Drawing.Font("Monotype Corsiva", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Caption_label.ForeColor = System.Drawing.Color.Gray;
            this.Caption_label.Location = new System.Drawing.Point(342, 37);
            this.Caption_label.Name = "Caption_label";
            this.Caption_label.Size = new System.Drawing.Size(97, 17);
            this.Caption_label.TabIndex = 39;
            this.Caption_label.Text = "A sense of place.";
            // 
            // Titlelabel
            // 
            this.Titlelabel.AutoSize = true;
            this.Titlelabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titlelabel.Location = new System.Drawing.Point(17, 102);
            this.Titlelabel.Name = "Titlelabel";
            this.Titlelabel.Size = new System.Drawing.Size(42, 16);
            this.Titlelabel.TabIndex = 40;
            this.Titlelabel.Text = "Title:";
            // 
            // TitlecomboBox
            // 
            this.TitlecomboBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.TitlecomboBox.FormattingEnabled = true;
            this.TitlecomboBox.Items.AddRange(new object[] {
            "Mr.",
            "Miss.",
            "Mrs."});
            this.TitlecomboBox.Location = new System.Drawing.Point(180, 98);
            this.TitlecomboBox.Name = "TitlecomboBox";
            this.TitlecomboBox.Size = new System.Drawing.Size(121, 24);
            this.TitlecomboBox.TabIndex = 41;
            this.TitlecomboBox.Text = "Title";
            this.TitlecomboBox.Click += new System.EventHandler(this.TitlecomboBox_Click);
            this.TitlecomboBox.Enter += new System.EventHandler(this.TitlecomboBox_Enter);
            this.TitlecomboBox.Leave += new System.EventHandler(this.TitlecomboBox_Leave);
            // 
            // Street_Address_label
            // 
            this.Street_Address_label.AutoSize = true;
            this.Street_Address_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Street_Address_label.Location = new System.Drawing.Point(14, 211);
            this.Street_Address_label.Name = "Street_Address_label";
            this.Street_Address_label.Size = new System.Drawing.Size(115, 16);
            this.Street_Address_label.TabIndex = 42;
            this.Street_Address_label.Text = "Street Address:";
            // 
            // Province_label
            // 
            this.Province_label.AutoSize = true;
            this.Province_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Province_label.Location = new System.Drawing.Point(17, 270);
            this.Province_label.Name = "Province_label";
            this.Province_label.Size = new System.Drawing.Size(71, 16);
            this.Province_label.TabIndex = 43;
            this.Province_label.Text = "Province:";
            // 
            // Citylabel
            // 
            this.Citylabel.AutoSize = true;
            this.Citylabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Citylabel.Location = new System.Drawing.Point(453, 211);
            this.Citylabel.Name = "Citylabel";
            this.Citylabel.Size = new System.Drawing.Size(39, 16);
            this.Citylabel.TabIndex = 44;
            this.Citylabel.Text = "City:";
            // 
            // PostalCode_label
            // 
            this.PostalCode_label.AutoSize = true;
            this.PostalCode_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalCode_label.Location = new System.Drawing.Point(440, 269);
            this.PostalCode_label.Name = "PostalCode_label";
            this.PostalCode_label.Size = new System.Drawing.Size(93, 16);
            this.PostalCode_label.TabIndex = 45;
            this.PostalCode_label.Text = "Postal Code:";
            // 
            // Country_label
            // 
            this.Country_label.AutoSize = true;
            this.Country_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Country_label.Location = new System.Drawing.Point(292, 267);
            this.Country_label.Name = "Country_label";
            this.Country_label.Size = new System.Drawing.Size(65, 16);
            this.Country_label.TabIndex = 46;
            this.Country_label.Text = "Country:";
            // 
            // Phone_No_label
            // 
            this.Phone_No_label.AutoSize = true;
            this.Phone_No_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_No_label.Location = new System.Drawing.Point(20, 325);
            this.Phone_No_label.Name = "Phone_No_label";
            this.Phone_No_label.Size = new System.Drawing.Size(76, 16);
            this.Phone_No_label.TabIndex = 47;
            this.Phone_No_label.Text = "Phone No:";
            // 
            // Street_Address_textBox
            // 
            this.Street_Address_textBox.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Street_Address_textBox.Location = new System.Drawing.Point(180, 211);
            this.Street_Address_textBox.Multiline = true;
            this.Street_Address_textBox.Name = "Street_Address_textBox";
            this.Street_Address_textBox.Size = new System.Drawing.Size(252, 22);
            this.Street_Address_textBox.TabIndex = 48;
            this.Street_Address_textBox.Click += new System.EventHandler(this.Street_Address_textBox_Click);
            // 
            // CitytextBox
            // 
            this.CitytextBox.Location = new System.Drawing.Point(539, 207);
            this.CitytextBox.Name = "CitytextBox";
            this.CitytextBox.Size = new System.Drawing.Size(100, 22);
            this.CitytextBox.TabIndex = 49;
            this.CitytextBox.Click += new System.EventHandler(this.CitytextBox_Click);
            // 
            // ProvincetextBox
            // 
            this.ProvincetextBox.Location = new System.Drawing.Point(180, 266);
            this.ProvincetextBox.Name = "ProvincetextBox";
            this.ProvincetextBox.Size = new System.Drawing.Size(71, 22);
            this.ProvincetextBox.TabIndex = 50;
            this.ProvincetextBox.Click += new System.EventHandler(this.ProvincetextBox_Click);
            // 
            // CountrytextBox
            // 
            this.CountrytextBox.Location = new System.Drawing.Point(369, 264);
            this.CountrytextBox.Name = "CountrytextBox";
            this.CountrytextBox.Size = new System.Drawing.Size(63, 22);
            this.CountrytextBox.TabIndex = 51;
            this.CountrytextBox.Click += new System.EventHandler(this.CountrytextBox_Click);
            // 
            // PostalCodetextBox
            // 
            this.PostalCodetextBox.Location = new System.Drawing.Point(539, 263);
            this.PostalCodetextBox.Name = "PostalCodetextBox";
            this.PostalCodetextBox.Size = new System.Drawing.Size(100, 22);
            this.PostalCodetextBox.TabIndex = 52;
            this.PostalCodetextBox.Click += new System.EventHandler(this.PostalCodetextBox_Click);
            // 
            // Phone_No_textBox
            // 
            this.Phone_No_textBox.Location = new System.Drawing.Point(180, 325);
            this.Phone_No_textBox.Name = "Phone_No_textBox";
            this.Phone_No_textBox.Size = new System.Drawing.Size(177, 22);
            this.Phone_No_textBox.TabIndex = 53;
            this.Phone_No_textBox.Click += new System.EventHandler(this.Phone_No_textBox_Click);
            // 
            // No_of_Nights_label
            // 
            this.No_of_Nights_label.AutoSize = true;
            this.No_of_Nights_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.No_of_Nights_label.Location = new System.Drawing.Point(20, 620);
            this.No_of_Nights_label.Name = "No_of_Nights_label";
            this.No_of_Nights_label.Size = new System.Drawing.Size(94, 16);
            this.No_of_Nights_label.TabIndex = 54;
            this.No_of_Nights_label.Text = "No of nights:";
            // 
            // NoOfNights_numericUpDown
            // 
            this.NoOfNights_numericUpDown.Location = new System.Drawing.Point(180, 614);
            this.NoOfNights_numericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NoOfNights_numericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NoOfNights_numericUpDown.Name = "NoOfNights_numericUpDown";
            this.NoOfNights_numericUpDown.Size = new System.Drawing.Size(120, 22);
            this.NoOfNights_numericUpDown.TabIndex = 55;
            this.NoOfNights_numericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NoOfNights_numericUpDown.Click += new System.EventHandler(this.NoOfNights_numericUpDown_Click);
            // 
            // Room_TypetextBox
            // 
            this.Room_TypetextBox.Location = new System.Drawing.Point(180, 473);
            this.Room_TypetextBox.Name = "Room_TypetextBox";
            this.Room_TypetextBox.ReadOnly = true;
            this.Room_TypetextBox.Size = new System.Drawing.Size(100, 22);
            this.Room_TypetextBox.TabIndex = 56;
            this.Room_TypetextBox.Text = "California King bed";
            this.Room_TypetextBox.Click += new System.EventHandler(this.Room_TypetextBox_Click_1);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(643, 689);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(75, 23);
            this.Clearbutton.TabIndex = 57;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Time_dateTimePicker
            // 
            this.Time_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.Time_dateTimePicker.Location = new System.Drawing.Point(323, 519);
            this.Time_dateTimePicker.Name = "Time_dateTimePicker";
            this.Time_dateTimePicker.Size = new System.Drawing.Size(126, 22);
            this.Time_dateTimePicker.TabIndex = 58;
            this.Time_dateTimePicker.Enter += new System.EventHandler(this.Time_dateTimePicker_Enter);
            // 
            // HotelBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(789, 900);
            this.Controls.Add(this.Time_dateTimePicker);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Room_TypetextBox);
            this.Controls.Add(this.NoOfNights_numericUpDown);
            this.Controls.Add(this.No_of_Nights_label);
            this.Controls.Add(this.Phone_No_textBox);
            this.Controls.Add(this.PostalCodetextBox);
            this.Controls.Add(this.CountrytextBox);
            this.Controls.Add(this.ProvincetextBox);
            this.Controls.Add(this.CitytextBox);
            this.Controls.Add(this.Street_Address_textBox);
            this.Controls.Add(this.Phone_No_label);
            this.Controls.Add(this.Country_label);
            this.Controls.Add(this.PostalCode_label);
            this.Controls.Add(this.Citylabel);
            this.Controls.Add(this.Province_label);
            this.Controls.Add(this.Street_Address_label);
            this.Controls.Add(this.TitlecomboBox);
            this.Controls.Add(this.Titlelabel);
            this.Controls.Add(this.Caption_label);
            this.Controls.Add(this.Summary_label);
            this.Controls.Add(this.Submitbutton);
            this.Controls.Add(this.HotelName_label);
            this.Controls.Add(this.Borderlabel);
            this.Controls.Add(this.NoofGuestsnumericUpDown);
            this.Controls.Add(this.DeparturedateTimePicker);
            this.Controls.Add(this.ArrivaldateTimePicker);
            this.Controls.Add(this.Departure_label);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Arrival_label);
            this.Controls.Add(this.No_of_Guests_label);
            this.Controls.Add(this.Roomtypelabel);
            this.Controls.Add(this.emailtextBox);
            this.Controls.Add(this.emaillabel);
            this.Controls.Add(this.lastnametextBox);
            this.Controls.Add(this.firstnametextBox);
            this.Controls.Add(this.Namelabel);
            this.Name = "HotelBooking";
            this.Text = "Hotel Booking";
            ((System.ComponentModel.ISupportInitialize)(this.NoofGuestsnumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfNights_numericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.TextBox firstnametextBox;
        private System.Windows.Forms.TextBox lastnametextBox;
        private System.Windows.Forms.Label emaillabel;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.Label Roomtypelabel;
        private System.Windows.Forms.Label No_of_Guests_label;
        private System.Windows.Forms.Label Arrival_label;
        private System.Windows.Forms.Label Departure_label;
        private System.Windows.Forms.DateTimePicker DeparturedateTimePicker;
        private System.Windows.Forms.DateTimePicker ArrivaldateTimePicker;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown NoofGuestsnumericUpDown;
        private System.Windows.Forms.Label Borderlabel;
        private System.Windows.Forms.Label HotelName_label;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label Summary_label;
        private System.Windows.Forms.Label Caption_label;
        private System.Windows.Forms.ComboBox TitlecomboBox;
        private System.Windows.Forms.Label Titlelabel;
        private System.Windows.Forms.TextBox Phone_No_textBox;
        private System.Windows.Forms.TextBox PostalCodetextBox;
        private System.Windows.Forms.TextBox CountrytextBox;
        private System.Windows.Forms.TextBox ProvincetextBox;
        private System.Windows.Forms.TextBox CitytextBox;
        private System.Windows.Forms.TextBox Street_Address_textBox;
        private System.Windows.Forms.Label Phone_No_label;
        private System.Windows.Forms.Label Country_label;
        private System.Windows.Forms.Label PostalCode_label;
        private System.Windows.Forms.Label Citylabel;
        private System.Windows.Forms.Label Province_label;
        private System.Windows.Forms.Label Street_Address_label;
        private System.Windows.Forms.NumericUpDown NoOfNights_numericUpDown;
        private System.Windows.Forms.Label No_of_Nights_label;
        private System.Windows.Forms.TextBox Room_TypetextBox;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.DateTimePicker Time_dateTimePicker;
    }
}

