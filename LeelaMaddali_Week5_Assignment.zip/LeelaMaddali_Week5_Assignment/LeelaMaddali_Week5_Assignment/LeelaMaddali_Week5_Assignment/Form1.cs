﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;


namespace LeelaMaddali_Week5_Assignment
{
    public partial class HotelBooking : Form
    {
        public HotelBooking()
        {
            InitializeComponent();
            MaximizeBox = false; // disable maximize box
            ArrivaldateTimePicker.Value = DateTime.UtcNow;// Set the time to present time when form loads
            DeparturedateTimePicker.Value = DateTime.UtcNow;// Set the time to present time when form loads
        }
            
        // an inctive text is given in the textboxes
        private void emailtextBox_Leave(object sender, EventArgs e)
        {
            if (emailtextBox.Text == "")
            {
                emailtextBox.Text = "eg: abc@xyz.com";
                emailtextBox.ForeColor = Color.Silver;
            }
            // validating the email address
            string pattern = "^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(emailtextBox.Text,pattern))
            {
                errorProvider1.Clear();   
            }
            else
            {
               errorProvider1.SetError(emailtextBox,"Please enter valid email address.");
            }
        }
  
        private void emailtextBox_Enter_1(object sender, EventArgs e)
        {
            if (emailtextBox.Text == "eg: abc@xyz.com")
            {
                emailtextBox.Text = "";
                emailtextBox.ForeColor = Color.Black;
            }
        }


        private void firstnametextBox_Leave(object sender, EventArgs e)
        {
            if (firstnametextBox.Text == "")
            {
                firstnametextBox.Text = "First Name";
                firstnametextBox.ForeColor = Color.Silver;
            }
        }
        private void firstnametextBox_Enter(object sender, EventArgs e)
        {
            if (firstnametextBox.Text == "First Name")
            {
                firstnametextBox.Text = "";
                firstnametextBox.ForeColor = Color.Black;
            }
        }

        private void lastnametextBox_Leave(object sender, EventArgs e)
        {
            if (lastnametextBox.Text == "")
            {
                lastnametextBox.Text = "Last Name";
                lastnametextBox.ForeColor = Color.Silver;
            }
        }

        private void lastnametextBox_Enter(object sender, EventArgs e)
        {
            if (lastnametextBox.Text == "Last Name")
            {
                lastnametextBox.Text = "";
                lastnametextBox.ForeColor = Color.Black;
            }
        }

        private void TitlecomboBox_Leave(object sender, EventArgs e)
        {
            if (TitlecomboBox.Text == "")
            {
                TitlecomboBox.Text = "Title";
                TitlecomboBox.ForeColor = Color.Silver;
            }
        }

        private void TitlecomboBox_Enter(object sender, EventArgs e)
        {
            if (TitlecomboBox.Text == "Title")
            {
                TitlecomboBox.Text = "";
                TitlecomboBox.ForeColor = Color.Black;
            }
        }

// check if all the information is provided and display the summary
        private void Submitbutton_Click(object sender, EventArgs e)
        {
            try
            {

                if (TitlecomboBox.Text == "Title" || firstnametextBox.Text == "First Name" || lastnametextBox.Text == "Last Name" || emailtextBox.Text == "eg: abc@xyz.com" || Street_Address_textBox.Text == "" || CitytextBox.Text == "" ||
                    ProvincetextBox.Text == "" || CountrytextBox.Text == "" || PostalCodetextBox.Text == "" || Phone_No_textBox.Text == "")
                {
                    MessageBox.Show("Please enter correct information. Some information is missing");
                }
                
               else if (ArrivaldateTimePicker.Value > DeparturedateTimePicker.Value)
                {
                   
                    MessageBox.Show("The departure date should be greater than return date.");

                }

                else if (System.Text.RegularExpressions.Regex.IsMatch(Phone_No_textBox.Text, "[^0-9]"))
                {
                    MessageBox.Show("Please enter numerics in phone field");
                    Phone_No_textBox.ResetText();
                    
                }
                
               else if (!System.Text.RegularExpressions.Regex.IsMatch(firstnametextBox.Text, "^[a-zA-Z ]"))
                {
                    MessageBox.Show("This textbox accepts only alphabetical characters");
                    firstnametextBox.ResetText();
                    
                }
                
                else if (!System.Text.RegularExpressions.Regex.IsMatch(lastnametextBox.Text, "^[a-zA-Z ]"))
                {
                    MessageBox.Show("This textbox accepts only alphabetical characters");
                    lastnametextBox.ResetText();
                   
                }
                
                else if (!this.emailtextBox.Text.Contains("@") || !this.emailtextBox.Text.Contains("."))
                {
                    MessageBox.Show("Please Enter A Valid Email", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    emailtextBox.ResetText();
                    
                }

                else
                {
                    Summary_label.Text = "SUMMARY\n" + "Name: " + TitlecomboBox.Text + " " + firstnametextBox.Text +
                                          " " + lastnametextBox.Text +
                                    "\nE-Mail ID: " + emailtextBox.Text +
                                    "\nNumber of Guests: " + NoofGuestsnumericUpDown.Value +
                                    "\nRoom Type: " + Room_TypetextBox.Text +
                                    "\nArrival Date && Time: " + ArrivaldateTimePicker.Text + " " + Time_dateTimePicker.Text +
                                    "\nDeparture Date: " + DeparturedateTimePicker.Text +
                                    "\nNo of nights:" + NoOfNights_numericUpDown.Value;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }   
        }


        // clears the summary when user go back and make changes in any of the fields.
        private void firstnametextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void lastnametextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void emailtextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void NoofGuestsnumericUpDown_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void ArrivaldateTimePicker_Enter(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void Time_dateTimePicker_Enter(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }
       
        private void DeparturedateTimePicker_Enter(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void TitlecomboBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void Street_Address_textBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void CitytextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void ProvincetextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void CountrytextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }

        private void PostalCodetextBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }
        private void Room_TypetextBox_Click_1(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }
        private void NoOfNights_numericUpDown_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }
        private void Phone_No_textBox_Click(object sender, EventArgs e)
        {
            Summary_label.Text = String.Empty;
        }
        // Changes the type of room according to the number of guests
        private void NoofGuestsnumericUpDown_Leave(object sender, EventArgs e)
        {
            if (NoofGuestsnumericUpDown.Value == 1)
            {
                Room_TypetextBox.Text = "California King bed";
            }
            else if (NoofGuestsnumericUpDown.Value > 4)
            {
                Room_TypetextBox.Text = "Family Suite";
            }
            else if(NoofGuestsnumericUpDown.Value <= 4)
            {
                Room_TypetextBox.Text = "2 Queen Beds";
            }

        }

        // Clears all the input given by the user
        private void Clearbutton_Click(object sender, EventArgs e)
        {
            TitlecomboBox.Text = String.Empty;
            firstnametextBox.Text = String.Empty;
            lastnametextBox.Text = String.Empty;
            Street_Address_textBox.Text = String.Empty;
            CitytextBox.Text = String.Empty;
            ProvincetextBox.Text = String.Empty;
            CountrytextBox.Text = String.Empty;
            PostalCodetextBox.Text = String.Empty;
            emailtextBox.Text = String.Empty;
            Room_TypetextBox.Text = String.Empty;
            NoofGuestsnumericUpDown.Value = 1;
            ArrivaldateTimePicker.Text = String.Empty;
            Time_dateTimePicker.Text = String.Empty;
            DeparturedateTimePicker.Text = String.Empty;
            NoOfNights_numericUpDown.Value = 1;
            Phone_No_textBox.Text = String.Empty;
            Summary_label.Text = String.Empty;
        }

    }
}
